
public class Kedi extends Kedigil {
	
	
public void uyu() {
		
		System.out.println("kedi uyudu");
	}
public void evcilOl() {
		
		System.out.println("kedi evcil oldu");
	}
public void sesC�kar() {
	
	System.out.println("kedi ses c�kard�------Miyavvv");
}
public void kosmaHizi(int hiz) {
	
	System.out.println("kedi kosma hizi"+hiz);public void uyu() {
		
		System.out.println("hayvan uyudu");
	}
}

}
