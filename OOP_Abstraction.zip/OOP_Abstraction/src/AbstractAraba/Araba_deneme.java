package AbstractAraba;

public class Araba_deneme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	//	Araba araba=new Araba();
		MotorluTasitlar mt=new MotorluTasitlar();
		mt.arabaPlaka("34 PS 3423");
		
		
		Araba a=new MotorluTasitlar();
		a.arabaPlaka("34 AAP 552");
	}

}
