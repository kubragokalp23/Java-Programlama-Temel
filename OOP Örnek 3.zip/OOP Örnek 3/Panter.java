
public class Panter extends Kedigil {
	
	
	
public void agacaCik() {
		
		System.out.println("panter agaca cikti");
	}
	

}
