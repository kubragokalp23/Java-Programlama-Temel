package AbstractAraba;

public class MotorluTasitlar extends Araba {

}
