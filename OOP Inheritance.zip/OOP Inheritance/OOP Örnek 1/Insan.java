
public class Insan extends Adem{
	
	
	
	/*
	 * �st s�n�fta olan metodu birebir alt s�n�ftada �retirsek metot override i�lemi yapm�� oluruz.
	 * 
	 * Metot override(ezme,ayn� metodun tekrar tan�mlanarak �st s�n�ftaki davran��tan vazge�ip alt s�n�ftaki gibi
	 * davranmas�n� sa�lamak i�in kullan�l�r.
	 * 
	 * Baz� zamanlarda metot override i�lemi yaparken, �st s�n�ftaki metot davran���n�n alt s�n�ftaki metot i�erisine ge�mesini isteyebilirz.
	 * E�er bu i�lemi yapmak istiyorsak super.metotAdi() gibi �a��rabiliriz.
	 * 
	 * 
	 * super()-�st s�n�f�n bo� constructoru demektir.E�er parantez i�erisinde arg�man g�nderirsek o da dolu constructor seviyesine denk gelir.
	 * 
	 * 
	 * 
	 */

	public void uyu() {
		
		
		System.out.println("insan uyudu");
	}
	
	public void sarkiSoyle()
	{
		
		System.out.println("insan sark� s�yledi");
	}
	
	public void  iseGit()
	{
		
		System.out.println("insan ise gitti");
	}
	
	public void kitapOku()
	{
		
		System.out.println("insan kitap okudu");
	}
	public void arabaSur()
	{
		
		System.out.println("insan araba s�rd�");
	}
	
	
	
	
}
