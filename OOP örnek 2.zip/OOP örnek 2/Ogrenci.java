
public class Ogrenci extends Egitim {
	
public void dersler() {
		
		System.out.println("ogrencinin dersleri");
	}

public void sinif(int sinif) {
	
	System.out.println("ogrenicinin sinifi"+sinif);
}

}
