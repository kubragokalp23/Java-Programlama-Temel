package PolymorphismVampir;

public class Vampir extends �nsan implements Yarasa{

	@Override
	public void uc() {
		// TODO Auto-generated method stub
		System.out.println("vampir uctu");
	}

	@Override
	public void isir() {
		// TODO Auto-generated method stub
		System.out.println("vampir isirdi");
	}

	
}
