
public class Kedigil_test {
	
	public static void main(String[] args) {

	Kedi kedi=new Kedi();//nesne urettik 
	kedi.evcilOl();
	kedi.kosmaHizi(10);
	kedi.sesC�kar();
	kedi.su�c();
	/*
	kedi s�n�f�n�n �st s�n�f� olan Kedigilde suIc metodu olamamas�na ragmen ,kedigilinde �st s�n�f� olan hayvan s�n�f� metodu olan suIc()
	metodu kedi s�n�f� dolayl� yoldan miras alm�� oldu.
	*/
	
	kedi.vahsiOl();// �st s�n�ftaki bir metodu dogrudan cag�rd�k.
	kedi.yemekYe();
	kedi.uyu();
	kedi.uyan();
	
	
	
	Aslan aslan=new Aslan();
	
	
	
	Panter panter=new Panter();
	
	
	}
}
