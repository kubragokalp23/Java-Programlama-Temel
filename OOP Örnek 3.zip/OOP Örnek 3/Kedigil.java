
public class Kedigil extends Hayvan {
	
	
	public void vahsiOl() {
		
		System.out.println("kedigil vah�i oldu");
	}
	public void yemekYe() {
		
		System.out.println("kedigil yemek yedi");
	}
	public void sesC�kar() {
		
		System.out.println("kedigil ses ��kard�");
	}
	public void kosmaHizi(int hiz) {
		
		System.out.println("kedigil kosma hizi"+hiz);
	}
}
