import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class Database {
	
	
	Connection baglanti=null;
	Statement st =null;
	
	
	public void baglantiAc(String veritabaniAdi,String dbUsername,String dbUserPass,String serverIp,int port)  {
		
			String baglantiCumlesi="jdbc:mysql://"+serverIp+":"+port+"/"+veritabaniAdi;

		
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
				baglanti=DriverManager.getConnection(baglantiCumlesi,dbUsername,dbUserPass);
				st= baglanti.createStatement();//statement s�n�f�n� connection s�n�f�na ba�lad�k
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch(SQLException i) {
				
				
			}
	
	/*
	 * 
	 * Connecti�n s�n�f� sayesinde veritanitaban�na baglanti islemi yapar�z.
	 * Connection s�n�f�,DriverManager s�n�f�n�n getConnection metoduna ba�lanmas� gerekir.
	 
	 
	 Statement s�n�f� sayesinde veritaban� sorgular� yazabiliriz.insert,update,delete,select gibi
	 
	 Statetement s�n�f�n�n executeQuery metodu sayesinde select sorgusunda bulunabiliriz.
	 executeUpdate metodu sayesinde insert,update,delete,select i�lemleri i�in kullan�l�r
	 */
	
	
	
	}
	public void baglant�Kapat() {
		try {
		if(!baglanti.isClosed()) {
			baglanti.close();
		}
		if(!st.isClosed()) {
			st.close();
		}
		}
		catch(SQLException e) {
			
			e.printStackTrace();
		}
		
	}
		public ResultSet verileriListele(String sorgu) {
			ResultSet rs=null;
			
			try {
				rs=st.executeQuery(sorgu);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return rs;
			
			
			
		}
		
		public void sorguGonder(String sorgu)
		{
			try {
				st.executeUpdate(sorgu);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//bu metot sayesinde do�rudan insert ,update ve delete sorgular� yaz�labilir.
		}
		
		public void veriSil(String tabloAdi,String sart) {
			
			try {
				st.executeUpdate("delete from"+tabloAdi+ "where"+sart);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//veriSil("ogrenci","id=1" );delete from pgrenciler where id=1
		}
		
		public int tablodakiVeriSayisi(String tabloAdi) {
			
			int sonuc=0;
			try {
				ResultSet rs=st.executeQuery("select count(*)as sayi from"+tabloAdi);
				sonuc=rs.getInt("sayi");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return 0;
			/*
			 * bu metot sayesinde arg�man olarak ald���m�z tabloya ait toplam sat�r say�s�n� bulabiliriz.
			 * 
			 */
		}
		
		
		public void veritabaniniSil(String veritabaniAdi)
		{
			
			try {
				st.executeUpdate("drop database"+veritabaniAdi);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		public void tabloSil(String tabloAdi) {
			
			try {
				st.executeUpdate("drop table"+tabloAdi);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
public void veritaban�Uret(String veritabaniAdi) {
			
			try {
				st.executeUpdate("create database"+veritabaniAdi);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

public void tabloUret(String tabloAdi,String argumanListesi) {
	
	//create table s�n�f (id int PRIMARY KEY AUTO_INCREAMENT ,ad varchar(25) null);
	
	try {
		st.executeUpdate("create table "+tabloAdi+"("+argumanListesi+")");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	//tabloUret("sinif",id int PRIMARY KEY AUTO_INCREMENT,ad varchar(25) null);
}

public void veriGuncelle(String tabloAdi,String guncelleme,String sart) {
	
	try {
		st.executeUpdate(" update "+tabloAdi+" set "+guncelleme+" where "+sart);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	//veriGuncelle("ogrenci","telefon_no"=123456,"id"=5
}

public void veriEkle(String tabloAdi,String eklenecekKolonlar,String eklenecekDegerler) {
	
	try {
		st.executeUpdate(" insert into "+tabloAdi+ "("+eklenecekKolonlar+ ") values ("+eklenecekDegerler+")" );
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	//veriEkle ("sinif","ad","'Lab 01'");
	
	
}
public int tablodakiVeriSayisi(String tabloAdi,String sart) {
	
	int sonuc=0;
	try {
		ResultSet rs=st.executeQuery("select count(*)as sayi from"+tabloAdi+ "where"+sart);
		sonuc=rs.getInt("sayi");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return 0;
	/*
	 * bu metot sayesinde arg�man olarak ald���m�z tabloya toplam sat�r say�s�n� bulabilirz
	 * 
	 */
}


}
	
