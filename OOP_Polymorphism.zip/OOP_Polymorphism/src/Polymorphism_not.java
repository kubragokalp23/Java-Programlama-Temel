
public class Polymorphism_not {

	/*
	 * Polymorphism(�ok bi�imlilik):
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 */
}
