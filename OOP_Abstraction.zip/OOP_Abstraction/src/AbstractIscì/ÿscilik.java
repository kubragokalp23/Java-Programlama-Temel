package AbstractIsc�;

public class �scilik extends �sci{

}
