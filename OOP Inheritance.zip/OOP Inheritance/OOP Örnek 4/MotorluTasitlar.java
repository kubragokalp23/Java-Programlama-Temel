
public class MotorluTasitlar {
	private String marka;
	private String renk;
	private int tekerlekSayisi;
	private int yakitTuru;
	private int vitesTuru;
	private double beygirGucu;
	
	public MotorluTasitlar() {
		super();
	}
	public MotorluTasitlar(String marka, String renk, int tekerlekSayisi, int yakitTuru, int vitesTuru,
			double beygirGucu) {
	
		this.marka = marka;
		this.renk = renk;
		this.tekerlekSayisi = tekerlekSayisi;
		this.yakitTuru = yakitTuru;
		this.vitesTuru = vitesTuru;
		this.beygirGucu = beygirGucu;
	}
	public String getMarka() {
		return marka;
	}
	public void setMarka(String marka) {
		this.marka = marka;
	}
	public String getRenk() {
		return renk;
	}
	public void setRenk(String renk) {
		this.renk = renk;
	}
	public int getTekerlekSayisi() {
		return tekerlekSayisi;
	}
	public void setTekerlekSayisi(int tekerlekSayisi) {
		this.tekerlekSayisi = tekerlekSayisi;
	}
	public int getYakitTuru() {
		return yakitTuru;
	}
	public void setYakitTuru(int yakitTuru) {
		this.yakitTuru = yakitTuru;
	}
	public int getVitesTuru() {
		return vitesTuru;
	}
	public void setVitesTuru(int vitesTuru) {
		this.vitesTuru = vitesTuru;
	}
	public double getBeygirGucu() {
		return beygirGucu;
	}
	public void setBeygirGucu(double beygirGucu) {
		this.beygirGucu = beygirGucu;
	}
	public void tur() {
		// TODO Auto-generated method stub
		
	}

	
	

}
