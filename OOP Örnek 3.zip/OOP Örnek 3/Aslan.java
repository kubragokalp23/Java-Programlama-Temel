
public class Aslan extends Kedigil{
	
	public void vahsiOl() {
		
		System.out.println("aslan vahsi oldu");
	}
	
	public void sesC�kar() {
		
		System.out.println("aslanses c�akrd�-waaaaaw!");
	}
	
	public void kosmaHizi(int hiz) {
		
		System.out.println("aslan�n kosma hizi"+hiz);
	}

}
