package PolymorphismVampir;

public class �nsan {

	
	public void yuru() {
		System.out.println("insan yuru");
	}
	public void konus(){
		System.out.println("insan konusr");
	}
	public void sarkiSoyle()
	{
		System.out.println("insan sarki s�yle");
		
	}
	

}
