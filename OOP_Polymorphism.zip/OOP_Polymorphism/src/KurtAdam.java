
public class KurtAdam extends Adam implements Kurt{

	@Override
	public void ulu() {
		// TODO Auto-generated method stub
		System.out.println("Kurt adam uludu");
	}

	@Override
	public void kos() {
		// TODO Auto-generated method stub
		System.out.println("Kurt adam kos");
	}

	@Override
	public void saldir() {
		// TODO Auto-generated method stub
		System.out.println("Kurt adam saldir");
	}

	@Override
	public void penceAt() {
		// TODO Auto-generated method stub
		System.out.println("Kurt adam pence at");
	}
	
	

}
