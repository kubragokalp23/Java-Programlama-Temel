
public class KurtAdam_deneme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		KurtAdam kurtadam=new KurtAdam();
		kurtadam.agla();
		kurtadam.dusun();
		kurtadam.giyin();
		kurtadam.konus();
		kurtadam.penceAt();
		kurtadam.saldir();
		kurtadam.ulu();
		kurtadam.yuru();
	}

}
