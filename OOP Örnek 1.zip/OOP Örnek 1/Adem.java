
public class Adem {

	
	public void yemekYe() {
		
		System.out.println("adem yemek yedi");
	}
	public void uyu() {
		
		
		System.out.println("adem uyudu");
	}
	
	public void uyan() {
		
		System.out.println("adem uyand�");
	}
	public void nefesAl() {
		
		
		System.out.println("adem nefes ald�");
	}
	public void konus() {
	
	
	System.out.println("adem konustu");
	}
	
	public void avla() {
	
	
	System.out.println("adem avlad�");
	}
	
	

	
	}
