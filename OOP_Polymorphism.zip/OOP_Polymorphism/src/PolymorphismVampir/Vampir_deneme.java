package PolymorphismVampir;

public class Vampir_deneme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Vampir vampir=new Vampir();
		
		vampir.isir();
		vampir.konus();
		vampir.sarkiSoyle();
		vampir.uc();
		vampir.yuru();
		
	}

}
