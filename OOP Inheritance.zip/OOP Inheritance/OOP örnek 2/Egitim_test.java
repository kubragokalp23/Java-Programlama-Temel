
public class Egitim_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Egitim egitim=new Egitim();
		
		Ogrenci ogrenci=new Ogrenci();
		ogrenci.dersler();
		ogrenci.sinif(4);
		ogrenci.materyal();
		ogrenci.materyal();
	
		
		
		
		Ogretmen ogretmen=new Ogretmen();
		ogretmen.adSoyad("ad soyad");
		ogretmen.dersler();
		ogretmen.materyal();
		ogretmen.materyal();
		
		
		
		 
		 
	}

}
