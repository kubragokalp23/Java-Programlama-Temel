
public class Egitim {
	
	
	public void mufredat()
	{
	System.out.println("mufredat");
	
	}
	public void materyal()
	{
	System.out.println("materyaller");
	
	}




}
