
public class Bisiklet extends MotorluTasitlar {	
	
	
	public Bisiklet(String marka, String renk, int tekerlekSayisi, int yakitTuru, int vitesTuru,
			double beygirGucu) {
		
		super(marka,renk,tekerlekSayisi,yakitTuru,vitesTuru,beygirGucu);
	
	}
	
	
	public void tur()
	{
		System.out.println("bisiklet");
	}

}
