import java.util.ArrayList;

public class MotorluTasit_deneme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<MotorluTasitlar>tasitlar=new ArrayList<MotorluTasitlar>();
		
		//String marka, String renk, int tekerlekSayisi, int yakitTuru, int vitesTuru,double beygirGucu)
		
		tasitlar.add(new Araba("Mercedes","K�rm�z�",4,1,2,2000));
		tasitlar.add(new Kamyon("volvo","beyaz",6,0,0,1500));
		tasitlar.add(new Tir("scana","beyaz",8,0,1,3000));
		tasitlar.add(new SUV("land rover","siyah",4,2,2,2000));
		
		
		for(MotorluTasitlar motorluTasitlar : tasitlar) {
			
			System.out.println("marka:"+motorluTasitlar.getMarka());
			System.out.println("renk:"+motorluTasitlar.getRenk());
			System.out.println("tekerlek sayisi:"+motorluTasitlar.getTekerlekSayisi());
			System.out.println("vitesturu:"+motorluTasitlar.getVitesTuru());
			System.out.println("yakitturu:"+motorluTasitlar.getYakitTuru());
			System.out.println("beygir gucu:"+motorluTasitlar.getBeygirGucu());
			motorluTasitlar.tur();// metot override islemi yapt�k
			
			System.out.println("-------------");
			if(motorluTasitlar instanceof Araba)
			{
				Araba araba=(Araba)motorluTasitlar;
				araba.yolcuSayisi(5);
			}
			
			System.out.println("---");
		}

	}

}
