
public class Tir extends MotorluTasitlar {

	
	
	public Tir(String marka, String renk, int tekerlekSayisi, int yakitTuru, int vitesTuru,
			double beygirGucu) {
		
		super(marka,renk,tekerlekSayisi,yakitTuru,vitesTuru,beygirGucu);
	
}
	public void tur()
	{
		System.out.println("tir");
	}
}
	
