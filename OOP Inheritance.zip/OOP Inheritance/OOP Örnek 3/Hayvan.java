
public class Hayvan {
	
	
	public void uyu() {
		
		System.out.println("hayvan uyudu");
	}

	public void uyan() {
	
	System.out.println("hayvan uyand�");
	
	}
	
	public void su�c() {
		
		System.out.println("hayvan su icti");
	}
	
	
	
	
	
}
