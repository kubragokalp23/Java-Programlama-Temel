
public class Insan_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Adem adem=new Adem();
		
		adem.avla();
		adem.konus();
		adem.nefesAl();
		adem.uyan();
		adem.uyu();
		adem.yemekYe();
		System.out.println("-------------------------");
		
		Insan insan=new Insan();
		
		insan.iseGit();
		insan.arabaSur();
		insan.kitapOku();
		insan.sarkiSoyle();
		insan.avla();
		insan.konus();
		insan.nefesAl();
		insan.uyu();
		insan.uyan();
	
		System.out.println("-------------------------");
		
		
		
	
	}

}
