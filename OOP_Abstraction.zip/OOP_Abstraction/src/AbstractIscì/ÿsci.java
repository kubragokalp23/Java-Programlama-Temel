package AbstractIsc�;

public abstract class �sci {

}
