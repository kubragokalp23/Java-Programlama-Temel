
public class Adam {

	
	public void konus() {
		System.out.println("Adam konus");
	}
	public void dusun(){
		System.out.println("adam a�lar");
	}
	public void yuru()
	{
		System.out.println("adam yurur");
		
	}
	public void giyin() {
		System.out.println("adam giyinir");
		
	}
	public void agla() {
		System.out.println("adam aglar");
		
	}
	
	
}
