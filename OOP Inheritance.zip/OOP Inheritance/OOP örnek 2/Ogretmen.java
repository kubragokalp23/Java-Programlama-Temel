
public class Ogretmen extends Egitim{

	
	public void dersler() {
		
		System.out.println("ogretmenin dersleri");
	}
	
	
	public void adSoyad(String adSoyad) {
		
		System.out.println("ogretmenin adi soyadi"+adSoyad);
	}
	
	
	
}
