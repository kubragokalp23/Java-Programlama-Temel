
public class Kamyon extends MotorluTasitlar {
	
	public Kamyon(String marka, String renk, int tekerlekSayisi, int yakitTuru, int vitesTuru,
			double beygirGucu) {
		super(marka,renk,tekerlekSayisi,yakitTuru,vitesTuru,beygirGucu);

	
	}
	public void tur()
	{
		System.out.println("kamyon");
	}
}
